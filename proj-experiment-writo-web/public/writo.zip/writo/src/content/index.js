function h(e,r){var a;const n=e.targetElement||document.activeElement;if(e.isContentEditable||n&&n.isContentEditable){const i=window.getSelection();if(e.range&&i)try{i.removeAllRanges(),i.addRange(e.range)}catch(t){console.warn("[Writo] Range re-selection failed, using active selection:",t)}if(i&&i.rangeCount>0){if(!document.execCommand("insertText",!1,r)&&e.range){e.range.deleteContents();const o=document.createTextNode(r);e.range.insertNode(o),e.range.selectNodeContents(o),e.range.collapse(!1)}return n&&(n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0}))),!0}}if(n&&(n instanceof HTMLTextAreaElement||n instanceof HTMLInputElement)){const i=e.startOffset??n.selectionStart??0,t=e.endOffset??n.selectionEnd??0;if(n.focus(),n.setSelectionRange(i,t),!document.execCommand("insertText",!1,r)){const c=n instanceof HTMLTextAreaElement?window.HTMLTextAreaElement.prototype:window.HTMLInputElement.prototype,w=(a=Object.getOwnPropertyDescriptor(c,"value"))==null?void 0:a.set,b=n.value,T=b.substring(0,i)+r+b.substring(t);w==null||w.call(n,T),n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0})),n.setSelectionRange(i+r.length,i+r.length)}return!0}return!1}let u=null,f=null,s=null,p=!1,d=!1,m="",E="",g="";function C(){if(f)return f;u=document.createElement("writo-extension-pill"),u.id="__writo_pill_root__",u.style.cssText="position: absolute; top: 0; left: 0; width: 0; height: 0; z-index: 2147483647; pointer-events: none;",f=u.attachShadow({mode:"closed"});const e=document.createElement("style");return e.textContent=`
    .writo-pill-container {
      position: absolute;
      pointer-events: auto;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      user-select: none;
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      gap: 4px;
      animation: writoFadeIn 0.15s ease-out;
    }
    @keyframes writoFadeIn {
      from { opacity: 0; transform: translateY(4px) scale(0.96); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
    .writo-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: #0f172a;
      color: #f8fafc;
      padding: 6px 12px;
      border-radius: 9999px;
      box-shadow: 0 4px 16px -1px rgba(0, 0, 0, 0.35), 0 2px 4px -2px rgba(0, 0, 0, 0.2);
      border: 1px solid #334155;
      cursor: pointer;
      transition: all 0.15s ease;
      white-space: nowrap;
    }
    .writo-pill:hover {
      background: #1e293b;
      border-color: #0e8ceb;
      box-shadow: 0 4px 20px -1px rgba(14, 140, 235, 0.35);
      transform: translateY(-1px);
    }
    .writo-menu {
      background: #090d16;
      border: 1px solid #1e293b;
      border-radius: 12px;
      padding: 6px;
      box-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.6), 0 0 0 1px rgba(255, 255, 255, 0.05);
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 200px;
    }
    .writo-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 8px 10px;
      border-radius: 8px;
      color: #cbd5e1;
      cursor: pointer;
      font-size: 12px;
      transition: all 0.12s ease;
    }
    .writo-item:hover {
      background: #1e293b;
      color: #f8fafc;
    }
    .writo-item.active {
      color: #38a9f7;
      font-weight: 600;
    }
    .writo-stop-btn {
      background: #334155;
      color: #f8fafc;
      border: none;
      border-radius: 9999px;
      padding: 2px 6px;
      margin-left: 4px;
      font-size: 10px;
      cursor: pointer;
    }
    .writo-stop-btn:hover {
      background: #ef4444;
    }
  `,f.appendChild(e),document.body.appendChild(u),f}function x(){const e=document.activeElement,r=window.getSelection();if(e&&(e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement)){const n=e.selectionStart??0,a=e.selectionEnd??0,i=e.value||"",t=i.substring(n,a).trim();if(t.length>1){const o=e.getBoundingClientRect();return{isContentEditable:!1,selectedText:t,fullText:i,boundingRect:{top:o.top+window.scrollY,left:o.left+window.scrollX,bottom:o.bottom+window.scrollY,right:o.right+window.scrollX,width:o.width,height:o.height},startOffset:n,endOffset:a,targetElement:e}}}if(r&&r.rangeCount>0&&!r.isCollapsed){const n=r.getRangeAt(0),a=n.toString().trim();if(a.length>1){const i=n.getBoundingClientRect(),t=n.commonAncestorContainer.parentElement;return{isContentEditable:!!(t!=null&&t.closest('[contenteditable="true"]')),selectedText:a,fullText:(t==null?void 0:t.innerText)||a,boundingRect:{top:i.top+window.scrollY,left:i.left+window.scrollX,bottom:i.bottom+window.scrollY,right:i.right+window.scrollX,width:i.width,height:i.height},range:n.cloneRange(),targetElement:(t==null?void 0:t.closest('[contenteditable="true"]'))||t}}}return null}function l(){var a,i;const e=C(),r=e.querySelector(".writo-pill-container");if(r&&r.remove(),!s&&!d)return;const n=document.createElement("div");if(n.className="writo-pill-container",s){const t=Math.max(10,s.boundingRect.top-42),o=Math.min(window.innerWidth-220,Math.max(10,s.boundingRect.left));n.style.top=`${t}px`,n.style.left=`${o}px`}if(d){n.innerHTML=`
      <div class="writo-pill">
        <span style="display:inline-block;animation:spin 1s linear infinite;">⏳</span>
        <span>Polishing with Writo AI...</span>
        <button class="writo-stop-btn" id="writo-cancel-btn" title="Cancel generation">✕</button>
      </div>
    `,(a=n.querySelector("#writo-cancel-btn"))==null||a.addEventListener("click",t=>{t.stopPropagation(),v()}),e.appendChild(n);return}if(p)n.innerHTML=`
      <div class="writo-menu">
        <div class="writo-item" data-action="improve">
          <span>✨ Improve Writing</span>
          <span style="opacity:0.5;font-size:10px;font-family:monospace;">Cmd+Enter</span>
        </div>
        <div class="writo-item" data-action="grammar">
          <span>✓ Fix Grammar</span>
        </div>
        <div class="writo-item" data-action="professional">
          <span>💼 Professional Tone</span>
        </div>
        <div class="writo-item" data-action="simplify">
          <span>🪶 Simplify</span>
        </div>
        <div class="writo-item" data-action="concise">
          <span>✂ Make Concise</span>
        </div>
        <div style="height:1px;background:#1e293b;margin:4px 0;"></div>
        <div class="writo-item" data-action="sidepanel">
          <span>📖 Open Side Panel</span>
          <span style="opacity:0.5;font-size:10px;">Full Workspace</span>
        </div>
      </div>
    `,n.querySelectorAll(".writo-item").forEach(t=>{t.addEventListener("click",o=>{o.stopPropagation();const c=t.dataset.action;if(c){if(c==="sidepanel"){chrome.runtime.sendMessage({type:"OPEN_SIDEPANEL"}),p=!1,l();return}y(c)}})});else{const t=(s==null?void 0:s.selectedText.split(/\s+/).length)||0;n.innerHTML=`
      <div class="writo-pill" id="writo-trigger-btn">
        <span style="color:#38a9f7;font-size:14px;">✨</span>
        <span style="font-weight:600;letter-spacing:-0.01em;">Writo</span>
        <span style="opacity:0.5;font-size:11px;">(${t}w)</span>
      </div>
    `,(i=n.querySelector("#writo-trigger-btn"))==null||i.addEventListener("click",o=>{o.stopPropagation(),p=!0,l()})}e.appendChild(n)}function v(){d&&m&&chrome.runtime.sendMessage({type:"CANCEL_ACTION",requestId:m}),d=!1,l()}function y(e,r){const n=r||(s==null?void 0:s.selectedText);n&&(E=n,g="",d=!0,p=!1,m=`req-${Date.now()}`,l(),chrome.runtime.sendMessage({type:"EXECUTE_ACTION",requestId:m,payload:{action:e,text:E}}))}chrome.runtime.onMessage.addListener((e,r,n)=>{var a,i;if(e.type==="STREAM_TOKEN"&&e.requestId===m){const t=e.payload;if(t.error){alert(`Writo AI Error: ${t.error}`),d=!1,l();return}t.fullText&&(g=t.fullText),t.isDone&&(d=!1,s&&g.trim()&&h(s,g.trim()),s=null,l())}if(e.type==="EXECUTE_ACTION"){const t=e.payload,o=x();return o&&(s=o),(s||t.text)&&y(t.action,t.text),n({started:!0}),!0}if(e.type==="GET_ACTIVE_SELECTION"){const t=x(),o=(t==null?void 0:t.selectedText)||((a=window.getSelection())==null?void 0:a.toString().trim())||"";return n({selectedText:o}),!0}if(e.type==="APPLY_TO_ACTIVE_PAGE"){const t=(i=e.payload)==null?void 0:i.text;if(t){const o=s||x();if(o)h(o,t);else{const c=document.activeElement;(c instanceof HTMLTextAreaElement||c instanceof HTMLInputElement)&&(c.focus(),document.execCommand("insertText",!1,t))}}return n({applied:!0}),!0}});document.addEventListener("mouseup",()=>{setTimeout(()=>{if(d)return;const e=x();e&&e.selectedText.length>1?(s=e,l()):p||(s=null,l())},10)});document.addEventListener("keyup",e=>{e.key==="Escape"&&(d?v():(p=!1,s=null,l()))});document.addEventListener("mousedown",e=>{u&&e.composedPath().includes(u)||p&&(p=!1,l())});
